﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GameSupply.StandaloneScripts
{
    class StatusContainer
    {
        public static int UserStatus;
    }
}
