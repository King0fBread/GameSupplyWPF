﻿using System.Windows.Controls;

namespace GameSupply.StandaloneScripts
{
    class PageNavigationManager
    {
        public static Frame MainFrame { get; set; }
    }
}
