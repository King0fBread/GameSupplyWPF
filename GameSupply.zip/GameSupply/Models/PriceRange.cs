﻿using System;
using System.Collections.Generic;

#nullable disable

namespace GameSupply.Models
{
    public partial class PriceRange
    {
        public int IdPriceRange { get; set; }
        public string RangeName { get; set; }
    }
}
